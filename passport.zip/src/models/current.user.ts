export class CurrentUser {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
}

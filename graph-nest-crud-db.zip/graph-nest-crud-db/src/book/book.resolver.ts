import { Resolver, Query, Args, Mutation, Int } from "@nestjs/graphql";
import { BookService } from "./book.service";
import { Book } from "./schema/book.schema";
import { Book as bm } from '../graphql'
import { AddBookArgs } from "./args/add.book.args";
import { UpdateBookArgs } from "./args/update.book.args";
@Resolver((of) => Book)
export class BookResolver {
    constructor(private readonly bs: BookService) { }

    @Query((returns) => [Book], { name: "books" })
    getAllBooks() {
        return this.bs.findAllBooks()
    }


    @Query(returns => Book, { name: "bookById"})

    getBookById(@Args({ name: "bookId", type: () => Int }) id: number) {
        return this.bs.findAllBookById(id)
    }


    @Mutation(returns => String, { name: "deleteBook" })

    deleteBookById(@Args({ name: "bookId", type: () => Int }) id: number) {
        return this.bs.deleteBook(id);
    }





    @Mutation(returns => String, { name: "addBook" })

    addBook(@Args("addBookArgs") addBookArgs: AddBookArgs) {
        return this.bs.addBook(addBookArgs);
    }
    
    @Mutation(returns => String, { name: "updateBook" })
    updateBook(@Args({ name: "bookId", type: () => Int }) id: number, @Args("updateBookArgs") updateBookArgs: UpdateBookArgs) {
        return this.bs.updateBook(updateBookArgs);
    }




}
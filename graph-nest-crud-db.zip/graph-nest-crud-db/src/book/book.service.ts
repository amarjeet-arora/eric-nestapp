import { Injectable } from '@nestjs/common';
import { BookEntity } from './entity/book.entity';
import { AddBookArgs } from './args/add.book.args';
import { UpdateBookArgs } from './args/update.book.args';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
 
@Injectable()
export class BookService {

constructor(@InjectRepository(BookEntity) public readonly bookRepo: Repository<BookEntity>){}
    
async findAllBooks():Promise<BookEntity[]>{
let books=await this.bookRepo.find();
return books;
}

async findAllBookById(id:number):Promise<BookEntity>{
    let book=await this.bookRepo.findOne({where: {id:id}})

    return book;
    }
async deleteBook(id: number): Promise<string> {

await this.bookRepo.delete(id);
return "Book Has Been Deleted";
}

async addBook(addBookArgs: AddBookArgs): Promise<string> {
let book: BookEntity= new BookEntity()
book.title =addBookArgs.title;
book.price=addBookArgs.price;

await this.bookRepo.save(book);
return "Book has Been Sucesfully Added";
}

 
async updateBook (addBookArgs: UpdateBookArgs): Promise<string> {
    //let book: BookEntity= await this.bookRepo.findOne({where: {id:UpdateBookArgs.id}})
   // book.title =addBookArgs.title;
    //book.price=addBookArgs.price;
    
   // await this.bookRepo.save(book);
 
return "Book has Been Sucesfully Added";
}}
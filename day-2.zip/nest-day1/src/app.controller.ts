import {Controller, Get, Post, Put, Delete, Body} from '@nestjs/common';
 
@Controller()
export class AppController {
    @Get()
    getRootRoute() {
        return 'hi there';
    }
    @Get('/:id')
    getRootRouteWithPara() {
        return 'hi there with para';
    }
    @Post()
    POstRootRoute(@Body() body) {
        return 'user added' + body;
    }
    @Put('/:id')
    PutRootRoute() {
        return 'user update';
    }
    @Delete('/:id')
    deleteRootRoute() {
        return 'user Deleted';
    }
}

import {Module} from "@nestjs/common";
import {AppController} from './app.controller'
import { App2Controller } from "./app2.controller";
@Module({controllers: [AppController,App2Controller]})
export class AppModule {}

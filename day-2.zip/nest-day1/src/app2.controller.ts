import { Controller, Get } from "@nestjs/common";


@Controller('/mainapp')
export class App2Controller{

   @Get('/loadusers')
    loadUsers(){
        return "users loaded...!"
    }
    @Get('/loademps')
    loadEmps(){
        return "Employees loaded...!"
    }
}
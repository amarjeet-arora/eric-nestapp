export interface ICarDto {

    id: string
    make: string
    model:string
}

import { Controller, Get, Body, Post } from '@nestjs/common';
import { InjectModel } from '@nestjs/azure-database';
import { Car } from './car.entity';
import { Container } from '@azure/cosmos';
import { ICarDto } from './car.dto';

@Controller('car')
export class CarController {

    constructor(@InjectModel(Car) private readonly carContainer: Container){}
@Get('allcars')
    async loadCars(){
        var loadString="select * from c"

        var result= await this.carContainer?.items
             ?.query<Car>(loadString).fetchAll();

             var finalData=result.resources.map<ICarDto>((value) => {
                 return {
                     id:value.id,
                     make:value.make,
                     model:value.model
                 }
             })
             return finalData
    }
    @Post('create')
    async create(@Body() payload: ICarDto ){

        var newEntry= new Car();
        newEntry.id='2',
        newEntry.make=payload.make,
        newEntry.model=payload.model
        var {resource} =await this.carContainer.items.create(newEntry)
        return {
            id:resource.id,
            make:resource.make,
            model:resource.model

        }


        

    }
}

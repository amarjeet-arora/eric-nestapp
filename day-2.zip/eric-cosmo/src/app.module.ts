import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AzureCosmosDbModule } from '@nestjs/azure-database'
import { CarModule } from './car/car.module';

@Module({
  imports: [
    AzureCosmosDbModule.forRoot({
      dbName: 'vehicles',
      endpoint:'https://amar-cosmos.documents.azure.com:443/',
      key:'KTCJlJ3dJ28op7hzRmLiBC2IlfdcOSFluhHESERJLiwEXuxw5CKlsdpWkgy46tUFYkcZsERkVccvACDbnR5ktQ=='
    }),
    CarModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

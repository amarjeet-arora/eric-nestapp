

var express= require('express')
var app= express()
var bp= require('body-parser')
var _= require('underscore')

app.use(express.static('public'))
var uid=1
app.use(bp.json())
userData=[]

var middleware={
    requireAuth: function(req,res,next) {
        console.log('auth detected');
       next()
        
    },
    logger: function(req,res,next) {
        console.log(`Request ${new Date().toString()} ${req.method} ${req.originalUrl}`)
        next()
    }
}

app.use(middleware.logger)
// get request
app.get('/loadusers',(req,res)=>{
res.send(userData)
})
// get with ID
app.get('/loaduser/:id',middleware.requireAuth,(req,res)=>{
    let uid= parseInt(req.params.id)
     var mtd= _.findWhere(userData, {id:uid})
     /* userData.forEach(function (todo){
         if(uid == todo.id){
             mtd=todo
         }
        
     }) */
     if(mtd){
         res.send(mtd)
     }else{
         res.status(404).send('user not found')
     }
})

//delete

app.delete('/loaduser/:id',(req,res)=>{
    let uid= parseInt(req.params.id)
     var mtd= _.findWhere(userData, {id:uid})
     
     if(mtd){
         userData=_.without(userData,mtd)
         res.send('user deleted')
     }else{
         res.status(404).send('user not found')
     }
})


// post

app.post('/adduser',(req,res)=>{
    var data= req.body
    data.id=uid++
    userData.push(data)
    res.send(data)
})


app.listen(4000,()=>{
    console.log('server is ready...!');
    
})
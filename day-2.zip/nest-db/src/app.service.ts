import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserEvent } from './entity/userevent.entity';
import { Repository } from 'typeorm';

@Injectable()
export class AppService {
  constructor(@InjectRepository(UserEvent) private repo: Repository<UserEvent>){}

  createEvent(email:string,password:string) {

    const userevent= this.repo.create({email,password})

    return this.repo.save(userevent);
  }
}

import  { Entity, PrimaryGeneratedColumn, Column, AfterInsert } from 'typeorm'
@Entity()
export class UserEvent {
    @PrimaryGeneratedColumn()
    id: number
    @Column()
    email: string
    @Column()
    password:string
    
     @AfterInsert()
    afterInsert(){
        console.log('called after insert');
        
    }

}
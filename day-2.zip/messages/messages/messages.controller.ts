import { Controller } from '@nestjs/common';

@Controller('messages')
export class MessagesController {}

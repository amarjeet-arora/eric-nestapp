import { Controller, Get, Param, Post, Body, Patch, Delete, HttpCode } from '@nestjs/common';
import { UserEvent } from './UserEvent';
import { CreateUserEvent } from './dto/CreateEventDTO';
import { UserEventUpdate } from './dto/updateventDTO';

@Controller('userevent')
export class UsereventController {
    private events: UserEvent[]

    @Get()
    findAll() {
        return this.events;
    }
    @Get(':id')
    findById(@Param('id') id) {
        const event = this.events.find(
            event => event.id === parseInt(id)
        )
        return event


    }

    @Post()
    create(@Body() input: CreateUserEvent) {
        const event = {
            ...input,
            when: new Date(input.when),
            id: this.events.length + 1
        }
        this.events.push(event)
        return event

    }
    @Patch(":id")
    update(@Param('id') id, @Body() input: UserEventUpdate) {

        const index = this.events.findIndex(
            event => event.id === parseInt(id)
        )
        this.events[index] = {
            ...this.events[index],
            ...input,
            when: input.when ?
                new Date(input.when) : this.events[index].when
        }
        return this.events[index]

    }
    @Delete(':id')
    @HttpCode(204)
    remove(@Param('id') id) {
        this.events = this.events.filter(
            event => event.id !== parseInt(id)
        )


    }

}

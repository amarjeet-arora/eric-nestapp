

export class UserEvent {

    id: number
    name: string
    description: string
    when: Date
    adddress: string
}
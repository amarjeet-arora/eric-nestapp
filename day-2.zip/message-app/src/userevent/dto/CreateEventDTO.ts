




export class CreateUserEvent {

    
    name: string
    description: string
    when: Date
    adddress: string
}
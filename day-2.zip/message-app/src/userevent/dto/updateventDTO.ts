
import { PartialType } from '@nestjs/mapped-types'
import { CreateUserEvent } from './CreateEventDTO';

export class UserEventUpdate extends PartialType(CreateUserEvent){

    
}
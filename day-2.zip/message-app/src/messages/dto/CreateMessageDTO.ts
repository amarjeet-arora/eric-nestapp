import {IsString, isEmail} from 'class-validator'
export class CreateMessageDTO {

    @IsString()
    uname?:string
   
    email:string
    password:string
}
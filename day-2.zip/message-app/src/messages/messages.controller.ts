import {Controller, Get, Post, Put, Delete, Body} from '@nestjs/common';
import { CreateMessageDTO } from './dto/CreateMessageDTO';

@Controller('messages')
export class MessagesController {
@Get()
    getRootRoute() {
        return 'hi there';
    }
    @Get('/:id')
    getRootRouteWithPara() {
        return 'hi there with para';
    }
    @Post()
    POstRootRoute(@Body() body : CreateMessageDTO) {
        return  body;
    }
    @Put('/:id')
    PutRootRoute() {
        return 'user update';
    }
    @Delete('/:id')
    deleteRootRoute() {
        return 'user Deleted';
    }
}

import { AzureCosmosDbModule } from '@nestjs/azure-database';
import { Module } from '@nestjs/common';
import { CarModule } from './car/car.module';
 @Module({
  imports: [
    AzureCosmosDbModule.forRoot({
      dbName:"vehicles",
      endpoint:"https://amar-cosmos.documents.azure.com:443/",
      key:"KTCJlJ3dJ28op7hzRmLiBC2IlfdcOSFluhHESERJLiwEXuxw5CKlsdpWkgy46tUFYkcZsERkVccvACDbnR5ktQ=="
    }),
    CarModule,
  ],
})
export class AppModule {}
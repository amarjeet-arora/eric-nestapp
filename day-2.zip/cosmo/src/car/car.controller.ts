import { Container } from '@azure/cosmos';
import { InjectModel } from '@nestjs/azure-database';
import { Controller, Body, Post } from '@nestjs/common';
import { Car } from './car.entity';
import {  Get } from '@nestjs/common';
import { ICarDto } from './car.dto';
  
@Controller('car')
export class CarController {
  constructor(@InjectModel(Car) private readonly carContainer: Container) {}

@Get('all')
async getCars() {
  var sqlQuery = 'select * from c';
 
  var consmosResults = await this.carContainer?.items
	  ?.query<Car>(sqlQuery)
	  .fetchAll();
  var fanal = consmosResults.resources.map<ICarDto>((value) => {
	  return {
		id: value.id,
		make: value.make,
		model: value.model,
	  };
  });
  return fanal;
}

@Post('create')
async create(@Body() payload: ICarDto) {
var newCar = new Car();
newCar.id = '2';
newCar.make = payload.make;
newCar.model = payload.model;
var { resource } = await this.carContainer.items.create(newCar);
return {
  id: resource.id,
  make: resource.make,
  model: resource.model,
};
}}
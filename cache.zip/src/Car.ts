export interface Car {
    id: number;
    manufacturer: string;
    model: string;
    year: number;
  }
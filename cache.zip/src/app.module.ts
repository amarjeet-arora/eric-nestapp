import { Module, CacheModule } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
//import * as redisStore from 'cache-manager-redis-store';
const redisStore = require('cache-manager-redis-store').redisStore;
@Module({
  imports: [
    CacheModule.register({
      store: redisStore,
      port:6380,
      auth_pass:"eBvRiRjx60FbbLZYRum36vxgw01SW2VDRAzCaO1XXu4=",
      host:"amardns.redis.cache.windows.net",
      tls:{
        host:"amardns.redis.cache.windows.net"
      },
      
    })
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

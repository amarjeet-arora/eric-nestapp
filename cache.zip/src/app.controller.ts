import { Controller, Get, CACHE_MANAGER, Inject, CacheTTL } from '@nestjs/common';
import { AppService } from './app.service';
import { Cache } from 'cache-manager';

import { Car } from './Car';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache
    ) {}


  getHello(): string {
    return this.appService.getHello();
  }
  @Get()
  async getCars() {
    var carsFromRedis = await this.cacheManager.get<Car[]>('cars-store');
   
    if (carsFromRedis && carsFromRedis.length > 0) {
      return { loadedFromRedis: true, data: carsFromRedis };
    }
   
    await this.cacheManager.set<Car[]>("cars-store", this.fakeDatabase)
    return { loadedFromRedis: false, data: this.fakeDatabase };
  }
  fakeDatabase: Car[] = [
    {
      id: 1,
      manufacturer: 'Honda',
      model: 'Civic',
      year: 2021,
    },
    {
      id: 2,
      manufacturer: 'Hyundai',
      model: 'Venue',
      year: 2022,
    },
  ];
}

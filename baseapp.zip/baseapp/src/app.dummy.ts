export class AppDummy {
  public dummy(): string {
    return 'dummy';
  }
}
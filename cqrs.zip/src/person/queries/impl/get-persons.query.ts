export class GetPersonsQuery {}

export class SavePersonCommand {
  name: string;
  age: number;
}
